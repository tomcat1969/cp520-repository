package edu.uw.cp520.scg.domain;

public class InvoiceFooterTest {
}
